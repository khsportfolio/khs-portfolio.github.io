function setLanguage(lang) {
  document.querySelectorAll('[data-en]').forEach(el => {
    el.textContent = el.getAttribute(`data-${lang}`);
  });
}


  const engBtn = document.getElementById('eng-btn');
  const mmBtn = document.getElementById('mm-btn');

  function switchLanguage(lang) {
    document.querySelectorAll('[data-eng]').forEach(el => {
      if(lang === 'ENG'){
        el.textContent = el.getAttribute('data-eng');
      } else if(lang === 'MM'){
        el.textContent = el.getAttribute('data-mm');
      }
    });
  }

  engBtn.addEventListener('click', () => switchLanguage('ENG'));
  mmBtn.addEventListener('click', () => switchLanguage('MM'));

